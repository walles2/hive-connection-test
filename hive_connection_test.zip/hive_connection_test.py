from os import environ
import base64

from pyhive import hive
from thrift.transport import THttpClient

_HTTP_USER_TOKEN = 'token'

def lambda_handler(event, context):
    http_url = 'https://{}/sql/protocolv1/o/{}/{}'.format(
        environ['DATABRICKS_WORKSPACE_URL'],
        environ['DATABRICKS_WORKSPACE_ID'],
        environ['DATABRICKS_CLUSTER_ID']
    )

    transport = THttpClient.THttpClient(http_url)

    auth = f'{_HTTP_USER_TOKEN}:{environ["DATABRICKS_TOKEN"]}'
    auth = base64.standard_b64encode(auth.encode()).decode()
    transport.setCustomHeaders(dict(Authorization=f'Basic {auth}'))

    connection = hive.connect(thrift_transport=transport)
    cursor = connection.cursor()
    result = cursor.execute('SHOW tables')
    print(result)
    return result
